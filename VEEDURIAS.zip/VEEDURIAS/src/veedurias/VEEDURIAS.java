
package veedurias;

/**
 *
 * @author ERIK
 */
public class VEEDURIAS {

  
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
